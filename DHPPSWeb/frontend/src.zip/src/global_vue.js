var cityleft= 10000
var citytop= 10000
var lineleft= 10000
var linetop= 10000

export default{
    cityleft,
    citytop,
    lineleft,
    linetop,
}